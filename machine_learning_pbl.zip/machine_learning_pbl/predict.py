print("Prediction script started!")

import joblib
import json
import pandas as pd

# Load trained model
model = joblib.load("lung_cancer_model.joblib")

# Load metadata
with open("model_metadata.json", "r") as file:
    metadata = json.load(file)

# Get feature order
features = metadata["feature_order"]


# Prediction function
def predict_lung_cancer(patient_data):

    # Convert input into DataFrame
    input_df = pd.DataFrame(
        [patient_data],
        columns=features
    )

    # Generate prediction
    prediction = model.predict(input_df)[0]

    # Convert prediction into result
    if prediction == 1:
        return "YES - Model predicts a positive class"
    else:
        return "NO - Model predicts a negative class"


# Sample patient data
patient = {
    "GENDER": 1,
    "AGE": 50,
    "SMOKING": 1,
    "YELLOW_FINGERS": 0,
    "ANXIETY": 0,
    "PEER_PRESSURE": 0,
    "CHRONIC DISEASE": 0,
    "FATIGUE": 1,
    "ALLERGY": 0,
    "WHEEZING": 0,
    "ALCOHOL CONSUMING": 0,
    "COUGHING": 1,
    "SHORTNESS OF BREATH": 0,
    "SWALLOWING DIFFICULTY": 0,
    "CHEST PAIN": 0
}

# Call function
result = predict_lung_cancer(patient)

print("Prediction Result:", result)
print("Prediction script finished!")

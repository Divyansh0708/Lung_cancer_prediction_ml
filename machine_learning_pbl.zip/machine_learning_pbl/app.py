
import streamlit as st
import pandas as pd
import joblib
import json
import numpy as np
from datetime import datetime

# ==========================================
# 1. PAGE CONFIGURATION
# ==========================================

st.set_page_config(
    page_title="LungCare AI | ML Analytics",
    page_icon="🫁",
    layout="wide"
)

# ==========================================
# 2. LOAD MODEL AND METADATA
# ==========================================

@st.cache_resource
def load_model():
    return joblib.load("lung_cancer_model.joblib")

model = load_model()

with open("model_metadata.json", "r") as f:
    metadata = json.load(f)

features = metadata["feature_order"]
metrics = metadata.get("test_metrics", {})

# Safe metric lookup
def get_metric(*names):
    for name in names:
        if name in metrics:
            return float(metrics[name])
    return None

accuracy = get_metric("Accuracy", "accuracy")
precision = get_metric("Precision", "precision")
recall = get_metric("Recall", "recall")
f1 = get_metric("F1", "F1 Score", "f1")
cv_f1 = get_metric("CV F1 (mean)", "CV F1", "cv_f1")

# ==========================================
# 3. SESSION STATE
# ==========================================

if "history" not in st.session_state:
    st.session_state.history = []

# ==========================================
# 4. CUSTOM DESIGN
# ==========================================

st.markdown("""
<style>

.stApp {
    background: #F4F7FA;
}

.block-container {
    max-width: 1400px;
    padding-top: 2rem;
}

[data-testid="stSidebar"] {
    background: #142B40;
}

[data-testid="stSidebar"] * {
    color: white !important;
}

.hero {
    background: linear-gradient(120deg,#173B55,#168A88);
    padding: 32px;
    border-radius: 20px;
    color: white;
    margin-bottom: 25px;
}

.hero h1 {
    color: white !important;
    font-size: 32px;
}

.hero p {
    color: #E0F1F0 !important;
}

.card {
    background: white;
    padding: 22px;
    border: 1px solid #E5ECF2;
    border-radius: 16px;
    box-shadow: 0 5px 20px rgba(20,50,70,.04);
    margin-bottom: 15px;
}

.card-title {
    color: #718398;
    font-size: 13px;
    font-weight: 600;
}

.card-value {
    color: #173D56;
    font-size: 28px;
    font-weight: 800;
    margin-top: 8px;
}

.stButton > button,
.stFormSubmitButton > button {
    background: #168A88;
    color: white;
    border: none;
    border-radius: 10px;
    font-weight: 700;
    min-height: 44px;
}

.stButton > button:hover,
.stFormSubmitButton > button:hover {
    background: #116D6C;
    color: white;
}

div[data-testid="stForm"] {
    background: white;
    padding: 25px;
    border-radius: 17px;
    border: 1px solid #E5ECF2;
}

</style>
""", unsafe_allow_html=True)

# ==========================================
# 5. SIDEBAR NAVIGATION
# ==========================================

with st.sidebar:

    st.title("🫁 LungCare AI")
    st.caption("INTELLIGENT ML PLATFORM")
    st.divider()

    page = st.radio(
        "NAVIGATION",
        [
            "Model Insights",
            "Prediction Studio",
            "Prediction History"
        ]
    )

    st.divider()
    st.caption("MODEL INFORMATION")
    st.write("Algorithm: Random Forest")
    st.write(f"Input Features: {len(features)}")
    st.caption("Academic ML Project")

# ==========================================
# 6. MODEL INSIGHTS PAGE
# ==========================================

if page == "Model Insights":

    st.markdown("""
    <div class="hero">
        <h1>Model Analytics & Insights</h1>
        <p>Explore the dataset, machine learning
        workflow and model evaluation results.</p>
    </div>
    """, unsafe_allow_html=True)

    st.subheader("Model Performance")

    cols = st.columns(4)

    for col, label, value in zip(
        cols,
        ["Accuracy", "Precision", "Recall", "F1 Score"],
        [accuracy, precision, recall, f1]
    ):
        with col:
            display = (
                f"{value*100:.2f}%"
                if value is not None else "N/A"
            )

            st.markdown(f"""
            <div class="card">
                <div class="card-title">{label}</div>
                <div class="card-value">{display}</div>
            </div>
            """, unsafe_allow_html=True)

    st.divider()

    # Performance graph
    st.subheader("Performance Metrics Visualization")

    metric_data = {
        "Metric": [],
        "Score (%)": []
    }

    for name, value in [
        ("Accuracy", accuracy),
        ("Precision", precision),
        ("Recall", recall),
        ("F1 Score", f1)
    ]:
        if value is not None:
            metric_data["Metric"].append(name)
            metric_data["Score (%)"].append(value * 100)

    if metric_data["Metric"]:
        chart_df = pd.DataFrame(metric_data).set_index("Metric")
        st.bar_chart(chart_df, y="Score (%)", height=300)

    if cv_f1 is not None:
        st.metric("Cross-validation Mean F1 Score",
                  f"{cv_f1*100:.2f}%")

    st.divider()

    # Dataset information
    st.subheader("Dataset Overview")

    c1, c2, c3 = st.columns(3)

    c1.metric("Input Features", len(features))
    c2.metric("Algorithm", "Random Forest")
    c3.metric("Prediction Classes", 2)

    st.markdown("### Feature Information")

    st.dataframe(
        pd.DataFrame({
            "Feature Number": range(1, len(features) + 1),
            "Feature Name": features
        }),
        use_container_width=True,
        hide_index=True
    )

    st.divider()

    # ML workflow
    st.subheader("Machine Learning Workflow")

    workflow = [
        ("01", "Data Collection",
         "Survey-based lung cancer dataset"),
        ("02", "Preprocessing",
         "Data cleaning, encoding and preparation"),
        ("03", "Model Training",
         "Random Forest classification"),
        ("04", "Model Evaluation",
         "Evaluation using test metrics"),
        ("05", "Model Deployment",
         "Saved model loaded using Joblib")
    ]

    for number, title, description in workflow:
        st.markdown(f"""
        <div class="card">
            <b style="color:#168A88">{number}</b>
            &nbsp;&nbsp; <b style="color:#193D55">{title}</b>
            <p style="color:#718398;margin-top:8px">
                {description}
            </p>
        </div>
        """, unsafe_allow_html=True)

    st.divider()

    # Feature importance
    st.subheader("Feature Importance Analysis")

    if hasattr(model, "feature_importances_"):

        importance = model.feature_importances_

        importance_df = pd.DataFrame({
            "Feature": features,
            "Importance": importance
        }).sort_values("Importance", ascending=False)

        st.caption(
            "Shows the relative contribution of each feature "
            "to the Random Forest model's decisions."
        )

        st.bar_chart(
            importance_df.set_index("Feature"),
            y="Importance",
            horizontal=True,
            height=500
        )

        st.dataframe(
            importance_df,
            use_container_width=True,
            hide_index=True
        )

    else:
        st.info("Feature importance is unavailable for this model.")

    st.warning(
        "These metrics describe performance on the evaluation data. "
        "They do not establish clinical reliability or diagnostic accuracy."
    )

# ==========================================
# 7. PREDICTION STUDIO
# ==========================================

elif page == "Prediction Studio":

    st.markdown("""
    <div class="hero">
        <h1>AI Prediction Studio</h1>
        <p>Enter survey information to obtain a
        machine learning classification.</p>
    </div>
    """, unsafe_allow_html=True)

    with st.form("patient_form"):

        st.subheader("Personal Information")

        c1, c2 = st.columns(2)

        with c1:
            gender = st.selectbox(
                "Gender",
                ["Male", "Female"]
            )

        with c2:
            age = st.number_input(
                "Age",
                min_value=1,
                max_value=100,
                value=50
            )

        st.divider()
        st.subheader("Health & Lifestyle Information")

        questions = [
            "SMOKING",
            "YELLOW_FINGERS",
            "ANXIETY",
            "PEER_PRESSURE",
            "CHRONIC DISEASE",
            "FATIGUE",
            "ALLERGY",
            "WHEEZING",
            "ALCOHOL CONSUMING",
            "COUGHING",
            "SHORTNESS OF BREATH",
            "SWALLOWING DIFFICULTY",
            "CHEST PAIN"
        ]

        answers = {}
        left, right = st.columns(2)

        for i, question in enumerate(questions):

            target = left if i % 2 == 0 else right

            with target:
                answer = st.selectbox(
                    question.replace("_", " ").title(),
                    ["No", "Yes"],
                    key="survey_" + question
                )

                answers[question] = (
                    1 if answer == "Yes" else 0
                )

        submitted = st.form_submit_button(
            "Analyze & Generate Prediction",
            use_container_width=True
        )

    if submitted:

        patient_data = {
            "GENDER": metadata["encoding"]["GENDER"][
                "M" if gender == "Male" else "F"
            ],
            "AGE": age,
            **answers
        }

        input_df = pd.DataFrame(
            [patient_data],
            columns=features
        )

        prediction = int(model.predict(input_df)[0])

        st.divider()
        st.subheader("Prediction Analysis")

        # Get class probabilities
        if hasattr(model, "predict_proba"):

            probabilities = model.predict_proba(input_df)[0]
            classes = list(model.classes_)

            # Class 1 = YES, class 0 = NO
            probability_map = {
                int(cls): float(prob)
                for cls, prob in zip(classes, probabilities)
            }

            yes_probability = probability_map.get(1, 0.0)
            no_probability = probability_map.get(0, 0.0)

            # Display result
            result = "YES" if prediction == 1 else "NO"

            if prediction == 1:
                st.warning("Positive class predicted: YES")
            else:
                st.success("Negative class predicted: NO")

            st.markdown("### YES vs NO Probability")

            probability_df = pd.DataFrame({
                "Class": ["YES", "NO"],
                "Model Probability (%)": [
                    yes_probability * 100,
                    no_probability * 100
                ]
            }).set_index("Class")

            st.bar_chart(
                probability_df,
                horizontal=True,
                height=200
            )

            col1, col2 = st.columns(2)

            col1.metric(
                "YES Probability",
                f"{yes_probability*100:.2f}%"
            )

            col2.metric(
                "NO Probability",
                f"{no_probability*100:.2f}%"
            )

            # Description
            st.markdown("### Prediction Explanation")

            if prediction == 1:
                description = (
                    "The model assigned the submitted survey "
                    "information to the positive class (YES). "
                    "This means the model's learned patterns "
                    "favoured class YES for this input."
                )
            else:
                description = (
                    "The model assigned the submitted survey "
                    "information to the negative class (NO). "
                    "This means the model's learned patterns "
                    "favoured class NO for this input."
                )

            st.info(description)

            st.caption(
                "The displayed probabilities are model estimates, "
                "not a person's actual probability of having lung cancer. "
                "This academic tool is not a medical diagnostic system."
            )

        else:
            result = "YES" if prediction == 1 else "NO"

            st.write(f"Model classification: **{result}**")

            st.info(
                "This model does not support probability estimation. "
                "Only its predicted class is displayed."
            )

            yes_probability = None
            no_probability = None

        # Save prediction history
        st.session_state.history.append({
            "Date": datetime.now().strftime("%d-%m-%Y %H:%M"),
            "Age": age,
            "Gender": gender,
            "Prediction": result,
            "YES Probability": (
                round(yes_probability * 100, 2)
                if yes_probability is not None else "N/A"
            ),
            "NO Probability": (
                round(no_probability * 100, 2)
                if no_probability is not None else "N/A"
            )
        })

# ==========================================
# 8. PREDICTION HISTORY
# ==========================================

elif page == "Prediction History":

    st.markdown("""
    <div class="hero">
        <h1>Prediction History</h1>
        <p>Review previous model predictions from this session.</p>
    </div>
    """, unsafe_allow_html=True)

    if st.session_state.history:

        history_df = pd.DataFrame(st.session_state.history)

        a, b, c = st.columns(3)

        a.metric("Total Predictions", len(history_df))

        b.metric(
            "YES Predictions",
            (history_df["Prediction"] == "YES").sum()
        )

        c.metric(
            "NO Predictions",
            (history_df["Prediction"] == "NO").sum()
        )

        st.dataframe(
            history_df,
            use_container_width=True,
            hide_index=True
        )

        csv = history_df.to_csv(index=False).encode("utf-8")

        st.download_button(
            "Download History CSV",
            csv,
            "lungcare_history.csv",
            "text/csv"
        )

        if st.button("Clear History"):
            st.session_state.history = []
            st.rerun()

    else:
        st.info("No predictions have been generated yet.")

# ==========================================
# 9. FOOTER
# ==========================================

st.divider()

st.caption(
    "LungCare AI | Machine Learning Academic Project | "
    "Educational use only, not a medical diagnostic tool."
)

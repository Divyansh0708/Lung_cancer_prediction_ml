
import joblib
import json
import pandas as pd
import sklearn

# 1. Check Scikit-learn version
print("Scikit-learn version:", sklearn.__version__)

# 2. Load the saved model
model = joblib.load("lung_cancer_model.joblib")

print("Model loaded successfully!")

# 3. Load model metadata
with open("model_metadata.json", "r") as file:
    metadata = json.load(file)

# 4. Get the correct feature order
features = metadata["feature_order"]

# 5. Create sample patient input
patient_data = {
    "GENDER": 1,
    "AGE": 50,
    "SMOKING": 1,
    "YELLOW_FINGERS": 0,
    "ANXIETY": 0,
    "PEER_PRESSURE": 0,
    "CHRONIC DISEASE": 0,
    "FATIGUE": 1,
    "ALLERGY": 0,
    "WHEEZING": 0,
    "ALCOHOL CONSUMING": 0,
    "COUGHING": 1,
    "SHORTNESS OF BREATH": 0,
    "SWALLOWING DIFFICULTY": 0,
    "CHEST PAIN": 0
}

# 6. Convert input into DataFrame
input_df = pd.DataFrame([patient_data], columns=features)

# 7. Make prediction
prediction = model.predict(input_df)

# 8. Display result
if prediction[0] == 1:
    print("Prediction: YES")
else:
    print("Prediction: NO")

print("Testing completed!")
